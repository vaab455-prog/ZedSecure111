package dev.cluvex.zedsecure.desktop.platform

import dev.cluvex.zedsecure.desktop.core.Os
import dev.cluvex.zedsecure.desktop.core.exec
import java.io.File

object DesktopDeviceId {
    fun read(): String = runCatching {
        when (Os.current) {
            Os.LINUX -> linux()
            Os.WINDOWS -> windows()
            Os.MACOS -> macos()
            Os.OTHER -> null
        }
    }.getOrNull().orEmpty()

    fun osName(): String = when (Os.current) {
        Os.LINUX -> "Linux"
        Os.WINDOWS -> "Windows"
        Os.MACOS -> "macOS"
        Os.OTHER -> System.getProperty("os.name").orEmpty()
    }

    fun osVersion(): String = System.getProperty("os.version").orEmpty()

    fun modelName(): String = runCatching {
        when (Os.current) {
            Os.LINUX -> linuxModel()
            Os.MACOS -> macosModel()
            else -> null
        }
    }.getOrNull()?.takeIf { it.isNotBlank() } ?: System.getProperty("os.arch").orEmpty()

    private fun linux(): String? =
        listOf("/etc/machine-id", "/var/lib/dbus/machine-id")
            .asSequence()
            .mapNotNull { path -> runCatching { File(path).readText().trim() }.getOrNull() }
            .firstOrNull { it.isNotEmpty() }

    private fun linuxModel(): String? =
        listOf("/sys/devices/virtual/dmi/id/product_name", "/sys/firmware/devicetree/base/model")
            .asSequence()
            .mapNotNull { path -> runCatching { File(path).readText().trim('\u0000', ' ', '\t', '\r', '\n') }.getOrNull() }
            .firstOrNull { it.isNotEmpty() }

    private fun windows(): String? {
        val (code, out) = exec(
            "reg", "query", "HKLM\\SOFTWARE\\Microsoft\\Cryptography", "/v", "MachineGuid", "/reg:64",
            timeoutSec = 5,
        )
        if (code != 0) return null
        return out.lineSequence()
            .firstOrNull { it.contains("MachineGuid", ignoreCase = true) }
            ?.substringAfter("REG_SZ", "")
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
    }

    private fun macos(): String? {
        val (code, out) = exec("/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice", timeoutSec = 5)
        if (code != 0) return null
        return Regex("\"IOPlatformUUID\"\\s*=\\s*\"([^\"]+)\"")
            .find(out)
            ?.groupValues?.get(1)
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
    }

    private fun macosModel(): String? {
        val (code, out) = exec("/usr/sbin/sysctl", "-n", "hw.model", timeoutSec = 5)
        if (code != 0) return null
        return out.trim().takeIf { it.isNotEmpty() }
    }
}
