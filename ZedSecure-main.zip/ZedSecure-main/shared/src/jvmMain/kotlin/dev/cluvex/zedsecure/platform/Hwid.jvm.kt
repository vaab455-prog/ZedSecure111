package dev.cluvex.zedsecure.platform

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

internal actual fun deriveHwid(seed: String): String {
    val mac = Mac.getInstance("HmacSHA256")
    mac.init(SecretKeySpec("ZedSecure x-hwid v1".toByteArray(Charsets.UTF_8), "HmacSHA256"))
    val digest = mac.doFinal(seed.toByteArray(Charsets.UTF_8))
    return digest.copyOf(16).joinToString("") { (it.toInt() and 0xff).toString(16).padStart(2, '0') }
}

internal actual fun platformDeviceHeaders(): Map<String, String> {
    val os = sanitizeHeaderValue(DeviceIdentity.os.ifBlank { fallbackOsName() })
    val verOs = sanitizeHeaderValue(DeviceIdentity.osVersion.ifBlank { fallbackOsVersion() })
    val model = sanitizeHeaderValue(DeviceIdentity.model.ifBlank { fallbackDeviceModel() })
    return buildMap {
        if (os.isNotEmpty()) put("x-device-os", os)
        if (verOs.isNotEmpty()) put("x-ver-os", verOs)
        if (model.isNotEmpty()) put("x-device-model", model)
    }
}

private fun sanitizeHeaderValue(raw: String): String =
    raw.filter { it.code in 0x20..0x7E }.trim().replace(Regex("\\s+"), " ").take(64)

private fun fallbackOsName(): String {
    if (JvmRuntime.android) return "Android"
    val raw = System.getProperty("os.name").orEmpty().lowercase()
    return when {
        "win" in raw -> "Windows"
        "mac" in raw || "darwin" in raw -> "macOS"
        "nux" in raw || "nix" in raw -> "Linux"
        else -> System.getProperty("os.name").orEmpty()
    }
}

private fun fallbackOsVersion(): String {
    if (JvmRuntime.android) {
        val release = runCatching {
            Class.forName("android.os.Build\$VERSION").getField("RELEASE").get(null) as? String
        }.getOrNull()
        if (!release.isNullOrBlank()) return release
    }
    return System.getProperty("os.version").orEmpty()
}

private fun fallbackDeviceModel(): String {
    if (JvmRuntime.android) {
        val manufacturer = runCatching {
            Class.forName("android.os.Build").getField("MANUFACTURER").get(null) as? String
        }.getOrNull().orEmpty().trim()
        val model = runCatching {
            Class.forName("android.os.Build").getField("MODEL").get(null) as? String
        }.getOrNull().orEmpty().trim()
        val combined = when {
            manufacturer.isEmpty() -> model
            model.isEmpty() -> manufacturer
            model.startsWith(manufacturer, ignoreCase = true) -> model
            else -> "${manufacturer.replaceFirstChar { it.uppercase() }} $model"
        }
        if (combined.isNotBlank()) return combined
    }
    return System.getProperty("os.arch").orEmpty()
}
