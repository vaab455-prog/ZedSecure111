package dev.cluvex.zedsecure.platform

internal expect fun deriveHwid(seed: String): String

internal expect fun platformDeviceHeaders(): Map<String, String>
