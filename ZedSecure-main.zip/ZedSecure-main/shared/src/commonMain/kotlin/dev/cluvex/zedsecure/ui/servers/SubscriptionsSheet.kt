@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package dev.cluvex.zedsecure.ui.servers

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.LaunchedEffect
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetValue
import androidx.compose.material3.rememberBottomSheetState
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.cluvex.zedsecure.shared.resources.Res
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.data.config.ConfigRepository
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import org.jetbrains.compose.resources.getString
import dev.cluvex.zedsecure.ui.components.SectionTitle
import dev.cluvex.zedsecure.ui.format.formatBytes
import dev.cluvex.zedsecure.ui.format.ltrIsolate
import androidx.compose.ui.graphics.luminance
import kotlinx.coroutines.launch
import dev.cluvex.zedsecure.ui.platform.appVerticalScroll
import org.jetbrains.compose.resources.StringResource

@Composable
fun SubscriptionsSheet(
    repository: ConfigRepository,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,

        sheetState = rememberBottomSheetState(SheetValue.Hidden, setOf(SheetValue.Hidden, SheetValue.Expanded)),
    ) {
        SubscriptionsPanel(
            repository = repository,
            onImported = onDismiss,
            showTitle = true,
            modifier = Modifier
                .fillMaxWidth()
                .appVerticalScroll(rememberScrollState())
                .imePadding()
                .padding(start = 20.dp, end = 20.dp, bottom = 26.dp),
        )
    }
}

@Composable
fun SubscriptionsPanel(
    repository: ConfigRepository,
    onImported: () -> Unit,
    showTitle: Boolean,
    modifier: Modifier = Modifier,
) {
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    val subs by repository.subscriptions.collectAsStateWithLifecycle()
    val currentHwid = remember(repository) { repository.currentHwid() }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var userAgent by remember { mutableStateOf("") }
    var groupName by remember { mutableStateOf("") }
    var busyId by remember { mutableStateOf<String?>(null) }
    var renameTarget by remember { mutableStateOf<dev.cluvex.zedsecure.domain.config.Subscription?>(null) }
    var deleteTarget by remember { mutableStateOf<dev.cluvex.zedsecure.domain.config.Subscription?>(null) }
    var qrTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    val listState = rememberLazyListState()
    var order by remember { mutableStateOf(subs) }
    LaunchedEffect(subs) { order = subs }
    val reorderState = rememberReorderableLazyListState(listState) { from, to ->
        val f = order.indexOfFirst { it.id == from.key }
        val t = order.indexOfFirst { it.id == to.key }
        if (f >= 0 && t >= 0) order = order.toMutableList().apply { add(t, removeAt(f)) }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (showTitle) {
            Text(
                stringResource(Res.string.subs_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
        }

        if (currentHwid.isNotBlank()) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "x-hwid",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            currentHwid,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(onClick = { platform.copyToClipboard(currentHwid) }) {
                        Icon(
                            painterResource(Res.drawable.ic_fill_content_copy),
                            contentDescription = stringResource(Res.string.action_copy),
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }
        }

        SectionTitle(stringResource(Res.string.subs_add))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(stringResource(Res.string.subs_name)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        val add = add@{
            if (url.isBlank()) return@add
            val sub = repository.addSubscription(name, url, userAgent)
            name = ""; url = ""; userAgent = ""
            busyId = sub.id
            scope.launch {
                repository.updateSubscription(sub.id)
                    .onSuccess {
                        platform.toast(getString(Res.string.servers_imported, it))

                        onImported()
                    }
                    .onFailure {
                        platform.toast(getString(Res.string.subs_failed))
                    }
                busyId = null
            }
        }
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text(stringResource(Res.string.subs_url)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { add() }),
            modifier = Modifier.fillMaxWidth(),
        )
        UserAgentPicker(userAgent) { userAgent = it }
        Button(
            onClick = { add() },
            enabled = url.isNotBlank(),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) {
            Text(stringResource(Res.string.subs_add_and_fetch), fontWeight = FontWeight.SemiBold)
        }

        SectionTitle(stringResource(Res.string.groups_add))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = groupName,
                onValueChange = { groupName = it },
                label = { Text(stringResource(Res.string.groups_name)) },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            Button(
                onClick = {
                    repository.addGroup(groupName)
                    groupName = ""
                },
                enabled = groupName.isNotBlank(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.height(50.dp),
            ) { Text(stringResource(Res.string.action_add)) }
        }

        if (subs.isNotEmpty()) {
            SectionTitle(stringResource(Res.string.subs_existing))
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxWidth().heightIn(max = 460.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(order, key = { it.id }) { sub ->
                    ReorderableItem(reorderState, key = sub.id) { dragging ->
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = if (dragging) MaterialTheme.colorScheme.surfaceContainerHighest
                            else MaterialTheme.colorScheme.surfaceContainerHigh,
                            shadowElevation = if (dragging) 6.dp else 0.dp,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                          Column {
                            Row(
                                Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    painterResource(Res.drawable.ic_drag_handle),
                                    contentDescription = stringResource(Res.string.subs_reorder),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(end = 8.dp).size(20.dp).draggableHandle(
                                        onDragStopped = {
                                            val target = subs.getOrNull(order.indexOfFirst { it.id == sub.id })
                                            if (target != null && target.id != sub.id) repository.moveSubscription(sub.id, target.id)
                                        },
                                    ),
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        sub.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        when {
                                            sub.serverCount > 0 -> stringResource(Res.string.servers_count, sub.serverCount)

                                            sub.url.isBlank() -> stringResource(Res.string.groups_add)
                                            else -> sub.url
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                Switch(
                                    checked = sub.enabled,
                                    onCheckedChange = { repository.setSubscriptionEnabled(sub.id, it) },
                                )
                                if (busyId == sub.id) {
                                    Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(Modifier.size(20.dp))
                                    }
                                } else {
                                    IconButton(onClick = {
                                        busyId = sub.id
                                        scope.launch {
                                            repository.updateSubscription(sub.id)
                                            busyId = null
                                        }
                                    }) {
                                        Icon(
                                            painterResource(Res.drawable.ic_schedule),
                                            contentDescription = stringResource(Res.string.subs_update),
                                        )
                                    }
                                }

                                IconButton(onClick = { qrTarget = sub.name to sub.url }) {
                                    Icon(
                                        painterResource(Res.drawable.ic_qr_code_2),
                                        contentDescription = stringResource(Res.string.action_share_qr),
                                    )
                                }
                                IconButton(onClick = { renameTarget = sub }) {
                                    Icon(
                                        painterResource(Res.drawable.ic_edit),
                                        contentDescription = stringResource(Res.string.subs_rename),
                                    )
                                }
                                IconButton(onClick = { deleteTarget = sub }) {
                                    Icon(
                                        painterResource(Res.drawable.ic_delete),
                                        contentDescription = stringResource(Res.string.action_delete),
                                    )
                                }
                            }
                            SubscriptionUsage(sub, onOpen = { platform.openUri(it) })
                          }
                        }
                                    }
                }
            }
        }
    }

    qrTarget?.let { (qrTitle, qrText) ->
        dev.cluvex.zedsecure.ui.components.QrDialog(
            title = qrTitle,
            text = qrText,
            copyLabel = stringResource(Res.string.action_copy),
            shareLabel = stringResource(Res.string.action_share),
            closeLabel = stringResource(Res.string.action_close),
            unsupportedLabel = stringResource(Res.string.qr_too_large),
            onCopy = { platform.copyToClipboard(qrText) },
            onShare = { platform.shareText(qrText) },
            onDismiss = { qrTarget = null },
        )
    }

    renameTarget?.let { target ->
        var newName by remember(target.id) { mutableStateOf(target.name) }
        var newUrl by remember(target.id) { mutableStateOf(target.url) }
        var newUa by remember(target.id) { mutableStateOf(target.userAgent.orEmpty()) }
        var preset by remember(target.id) { mutableStateOf(target.preset) }
        var presetOpen by remember(target.id) { mutableStateOf(!target.preset.isEmpty) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(stringResource(Res.string.subs_edit)) },
            text = {
                Column(
                    Modifier.heightIn(max = 560.dp).appVerticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text(stringResource(Res.string.subs_name)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )

                    OutlinedTextField(
                        value = newUrl,
                        onValueChange = { newUrl = it },
                        label = { Text(stringResource(Res.string.subs_url)) },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    UserAgentPicker(newUa) { newUa = it }
                    TextButton(onClick = { presetOpen = !presetOpen }) {
                        Text(stringResource(Res.string.subs_preset_title))
                    }
                    if (presetOpen) {
                        Text(
                            stringResource(Res.string.subs_preset_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PresetField(Res.string.subs_preset_address, preset.address) { preset = preset.copy(address = it) }
                        PresetField(Res.string.subs_preset_fingerprint, preset.fingerprint) { preset = preset.copy(fingerprint = it) }
                        PresetField(Res.string.subs_preset_alpn, preset.alpn) { preset = preset.copy(alpn = it) }
                        PresetField(Res.string.subs_preset_finalmask, preset.finalMask, singleLine = false) {
                            preset = preset.copy(finalMask = it)
                        }
                        PresetField(Res.string.subs_preset_ciphers, preset.cipherSuites) { preset = preset.copy(cipherSuites = it) }
                        PresetField(Res.string.subs_preset_ech, preset.echConfigList) { preset = preset.copy(echConfigList = it) }
                        dev.cluvex.zedsecure.ui.components.PickerField(
                            label = stringResource(Res.string.subs_preset_core),
                            options = listOf(
                                "" to stringResource(Res.string.subs_preset_core_link),
                                dev.cluvex.zedsecure.domain.config.SubscriptionPreset.CORE_XRAY to "Xray",
                                dev.cluvex.zedsecure.domain.config.SubscriptionPreset.CORE_SINGBOX to stringResource(Res.string.subs_preset_core_singbox),
                            ),
                            selected = preset.core,
                            onSelect = { preset = preset.copy(core = it) },
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val changed = preset != target.preset
                    repository.editSubscription(target.id, newName, newUa, newUrl, preset)
                    renameTarget = null
                    if (changed) {
                        busyId = target.id
                        scope.launch {
                            repository.updateSubscription(target.id)
                            busyId = null
                        }
                    }
                }) { Text(stringResource(Res.string.action_save)) }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) {
                    Text(stringResource(Res.string.action_cancel))
                }
            },
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            icon = { Icon(painterResource(Res.drawable.ic_delete), null) },
            title = { Text(stringResource(Res.string.subs_delete_confirm_title)) },
            text = { Text(stringResource(Res.string.subs_delete_confirm_body, target.name)) },
            confirmButton = {
                TextButton(onClick = {
                    repository.removeSubscription(target.id, alsoRemoveServers = true)
                    deleteTarget = null
                }) { Text(stringResource(Res.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) {
                    Text(stringResource(Res.string.action_cancel))
                }
            },
        )
    }
}

@Composable
private fun PresetField(label: StringResource, value: String, singleLine: Boolean = true, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(stringResource(label)) },
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 2,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun UserAgentPicker(value: String, onChange: (String) -> Unit) {
    val default = ConfigRepository.DEFAULT_UA
    val alt = ConfigRepository.ALT_UA
    val v2rayTun = ConfigRepository.V2RAYTUN_UA
    val happ = ConfigRepository.HAPP_UA
    val singBox = ConfigRepository.SING_BOX_UA
    val isDefault = value.isBlank() || value == default
    val isAlt = value == alt
    val isV2rayTun = value == v2rayTun
    val isHapp = value == happ
    val isSingBox = value == singBox
    var custom by remember { mutableStateOf(!isDefault && !isAlt && !isV2rayTun && !isHapp && !isSingBox) }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            stringResource(Res.string.subs_ua_preset),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        androidx.compose.foundation.layout.FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = isDefault && !custom,
                onClick = { custom = false; onChange("") },
                label = { Text(stringResource(Res.string.subs_ua_v2rayng), maxLines = 1) },
            )
            FilterChip(
                selected = isV2rayTun && !custom,
                onClick = { custom = false; onChange(v2rayTun) },
                label = { Text("v2RayTun", maxLines = 1) },
            )
            FilterChip(
                selected = isHapp && !custom,
                onClick = { custom = false; onChange(happ) },
                label = { Text("Happ", maxLines = 1) },
            )
            FilterChip(
                selected = isAlt && !custom,
                onClick = { custom = false; onChange(alt) },
                label = { Text(stringResource(Res.string.subs_ua_zedsecure), maxLines = 1) },
            )
            FilterChip(
                selected = isSingBox && !custom,
                onClick = { custom = false; onChange(singBox) },
                label = { Text("sing-box", maxLines = 1) },
            )
            FilterChip(
                selected = custom,
                onClick = { custom = true },
                label = { Text(stringResource(Res.string.subs_ua_custom), maxLines = 1) },
            )
        }
        if (custom) {
            OutlinedTextField(
                value = value,
                onValueChange = onChange,
                label = { Text(stringResource(Res.string.subs_user_agent)) },
                placeholder = { Text(default) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Text(
            stringResource(Res.string.subs_ua_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SubscriptionUsage(
    sub: dev.cluvex.zedsecure.domain.config.Subscription,
    onOpen: (String) -> Unit,
) {
    val used = sub.used
    val total = sub.total
    val expireAt = sub.expireAt
    if (used == null && total == null && expireAt == null && sub.supportUrl == null && sub.webPageUrl == null) return

    val now = dev.cluvex.zedsecure.platform.currentTimeMillis()
    val fraction = if (used != null && total != null && total > 0) (used.toDouble() / total).toFloat() else null
    val expired = expireAt != null && expireAt <= now
    val daysLeft = expireAt?.let { ((it - now) / 86_400_000L).toInt() }
    val exhausted = fraction != null && fraction >= 1f
    val warning = !expired && !exhausted && ((fraction != null && fraction >= 0.8f) || (daysLeft != null && daysLeft <= 3))
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val stateColor = when {
        expired || exhausted -> MaterialTheme.colorScheme.error
        warning -> if (dark) androidx.compose.ui.graphics.Color(0xFFFFB74D) else androidx.compose.ui.graphics.Color(0xFF9A5B00)
        else -> MaterialTheme.colorScheme.primary
    }

    Column(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val usageText = when {
                used != null && total != null ->
                    stringResource(Res.string.subs_usage, ltrIsolate(formatBytes(used)), ltrIsolate(formatBytes(total)))
                used != null -> stringResource(Res.string.subs_usage_unlimited, ltrIsolate(formatBytes(used)))
                else -> null
            }
            Text(
                usageText.orEmpty(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val expiryText = when {
                expired -> stringResource(Res.string.subs_expired)
                exhausted -> stringResource(Res.string.subs_quota_exhausted)
                daysLeft == null -> null
                daysLeft <= 0 -> stringResource(Res.string.subs_expires_today)
                daysLeft == 1 -> stringResource(Res.string.subs_one_day_left)
                else -> stringResource(Res.string.subs_days_left, daysLeft)
            }
            if (expiryText != null) {
                Text(
                    expiryText,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (expired || exhausted || warning) stateColor else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (fraction != null) {
            androidx.compose.material3.LinearProgressIndicator(
                progress = { fraction.coerceIn(0f, 1f) },
                color = stateColor,
                trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                modifier = Modifier.fillMaxWidth().height(4.dp),
            )
        }
        if (sub.supportUrl != null || sub.webPageUrl != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                sub.supportUrl?.let { url ->
                    androidx.compose.material3.AssistChip(
                        onClick = { onOpen(url) },
                        label = { Text(stringResource(Res.string.subs_support)) },
                        leadingIcon = { Icon(painterResource(Res.drawable.ic_info), null, Modifier.size(18.dp)) },
                    )
                }
                sub.webPageUrl?.let { url ->
                    androidx.compose.material3.AssistChip(
                        onClick = { onOpen(url) },
                        label = { Text(stringResource(Res.string.subs_website)) },
                        leadingIcon = { Icon(painterResource(Res.drawable.ic_public), null, Modifier.size(18.dp)) },
                    )
                }
            }
        }
    }
}
