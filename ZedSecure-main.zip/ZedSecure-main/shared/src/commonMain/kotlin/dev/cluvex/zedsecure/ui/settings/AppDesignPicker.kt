@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)

package dev.cluvex.zedsecure.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.domain.model.AppDesign
import dev.cluvex.zedsecure.shared.resources.Res
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.theme.ZedGradients
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@Composable
fun AppDesignPicker(selected: AppDesign, onSelect: (AppDesign) -> Unit) {
    SettingsSegment {
        Column(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 16.dp)) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(
                    stringResource(Res.string.home_design_title),
                    style = MaterialTheme.typography.bodyLargeEmphasized,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    stringResource(Res.string.home_design_sub),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().selectableGroup().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                DesignCard(
                    name = stringResource(Res.string.home_design_bento),
                    selected = selected == AppDesign.Bento,
                    modifier = Modifier.weight(1f),
                    onClick = { onSelect(AppDesign.Bento) },
                ) { BentoPreviewCard() }
                DesignCard(
                    name = stringResource(Res.string.home_design_pixel),
                    selected = selected == AppDesign.Pixel,
                    modifier = Modifier.weight(1f),
                    onClick = { onSelect(AppDesign.Pixel) },
                ) { PixelPreview() }
                DesignCard(
                    name = stringResource(Res.string.home_design_old),
                    selected = selected == AppDesign.Old,
                    modifier = Modifier.weight(1f),
                    onClick = { onSelect(AppDesign.Old) },
                ) { OldPreview() }
            }
        }
    }
}

@Composable
private fun PixelPreview() {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize().padding(7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Box(Modifier.fillMaxWidth().height(10.dp).padding(horizontal = 6.dp)) {
            Box(Modifier.size(width = 26.dp, height = 8.dp).clip(CircleShape).background(cs.surfaceContainerHigh))
        }
        Column(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(cs.surfaceContainer),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier.size(42.dp).clip(MaterialShapes.Cookie12Sided.toShape()).background(cs.primary),
            )
            Spacer(Modifier.height(6.dp))
            Box(Modifier.size(width = 40.dp, height = 5.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.7f)))
        }
        Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(cs.surfaceContainerHigh))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Box(Modifier.weight(1f).height(12.dp).clip(RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp, topEnd = 2.dp, bottomEnd = 2.dp)).background(cs.surfaceContainerHigh))
            Box(Modifier.weight(1f).height(12.dp).clip(RoundedCornerShape(topStart = 2.dp, bottomStart = 2.dp, topEnd = 6.dp, bottomEnd = 6.dp)).background(cs.surfaceContainerHigh))
        }
    }
}

@Composable
private fun DesignCard(
    name: String,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
    preview: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val corner by animateDpAsState(if (selected) 32.dp else 20.dp, MaterialTheme.motionScheme.fastSpatialSpec(), label = "design-corner")
    val shape = RoundedCornerShape(corner)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(shape)
                .background(cs.surface)
                .border(if (selected) 3.dp else 1.dp, if (selected) cs.primary else cs.outlineVariant, shape)
                .selectable(
                    selected = selected,
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(),
                    role = Role.RadioButton,
                    onClick = onClick,
                ),
        ) {
            preview()
            androidx.compose.animation.AnimatedVisibility(
                visible = selected,
                enter = scaleIn(MaterialTheme.motionScheme.fastSpatialSpec()),
                exit = scaleOut(MaterialTheme.motionScheme.fastSpatialSpec()),
                modifier = Modifier.align(Alignment.TopEnd).offset(x = (-10).dp, y = 10.dp),
            ) {
                Box(
                    Modifier.size(26.dp).clip(CircleShape).background(cs.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painterResource(Res.drawable.ic_check),
                        contentDescription = null,
                        tint = cs.onPrimary,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            name,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) cs.primary else cs.onSurfaceVariant,
        )
    }
}

@Composable
private fun BentoPreviewCard() {
    Box(Modifier.fillMaxSize().background(dev.cluvex.zedsecure.ui.bento.Bento.colors.ground)) {
        dev.cluvex.zedsecure.ui.bento.BentoDesignPreview()
    }
}

@Composable
private fun OldPreview() {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize().padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .size(62.dp)
                .clip(MaterialShapes.Cookie9Sided.toShape())
                .background(ZedGradients.idle),
            contentAlignment = Alignment.Center,
        ) {
            Text("Z", color = Color.White, style = MaterialTheme.typography.titleLargeEmphasized)
        }
        Spacer(Modifier.height(2.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(Modifier.weight(1f).height(26.dp).clip(RoundedCornerShape(7.dp)).background(cs.surfaceContainerHighest))
            Box(Modifier.weight(1f).height(26.dp).clip(RoundedCornerShape(7.dp)).background(cs.surfaceContainerHighest))
        }
        Box(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(7.dp)).background(cs.primaryContainer))
        Box(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(9.dp)).background(cs.primary))
    }
}
